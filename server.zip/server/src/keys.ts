export default{
    database: {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'ng_games_db'
    }
}